import { useState, useEffect, useCallback } from "react";

interface SolPriceState {
  price: number | null;
  loading: boolean;
  error: boolean;
  lastUpdated: Date | null;
}

const REFRESH_INTERVAL_MS = 30_000;

// Fetch from Binance, fall back to CoinGecko
async function fetchSolPrice(): Promise<number> {
  try {
    const res = await fetch(
      "https://api.binance.com/api/v3/ticker/price?symbol=SOLUSDT",
      { cache: "no-store" }
    );
    if (!res.ok) throw new Error("binance");
    const json = await res.json();
    const price = parseFloat(json.price);
    if (!isFinite(price) || price <= 0) throw new Error("binance-invalid");
    return price;
  } catch {
    // Fallback to CoinGecko
    const res = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd",
      { cache: "no-store" }
    );
    if (!res.ok) throw new Error("coingecko");
    const json = await res.json();
    const price = json?.solana?.usd;
    if (!price || !isFinite(price)) throw new Error("coingecko-invalid");
    return price;
  }
}

export function useSolPrice(): SolPriceState & { usdToSol: (usd: number) => number | null } {
  const [state, setState] = useState<SolPriceState>({
    price: null,
    loading: true,
    error: false,
    lastUpdated: null,
  });

  const refresh = useCallback(async () => {
    try {
      const price = await fetchSolPrice();
      setState({ price, loading: false, error: false, lastUpdated: new Date() });
    } catch {
      setState(prev => ({ ...prev, loading: false, error: true }));
    }
  }, []);

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, REFRESH_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [refresh]);

  const usdToSol = useCallback(
    (usd: number) => (state.price ? usd / state.price : null),
    [state.price]
  );

  return { ...state, usdToSol };
}
