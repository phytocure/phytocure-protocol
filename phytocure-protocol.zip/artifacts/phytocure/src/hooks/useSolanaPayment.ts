import { useCallback, useState } from "react";
import {
  Connection,
  PublicKey,
  SystemProgram,
  Transaction,
  LAMPORTS_PER_SOL,
} from "@solana/web3.js";
import { useWallet } from "@/contexts/WalletContext";

export type PaymentStatus =
  | "idle"
  | "building"
  | "awaiting_approval"
  | "sending"
  | "confirming"
  | "confirmed"
  | "error";

export interface PaymentResult {
  txHash: string;
  confirmed: boolean;
}

interface UseSolanaPaymentReturn {
  status: PaymentStatus;
  error: string | null;
  sendSol: (params: {
    recipient: string;
    amountSol: number;
    memo?: string;
  }) => Promise<PaymentResult | null>;
  reset: () => void;
}

function getPhantomProvider() {
  if (typeof window === "undefined") return null;
  if ("phantom" in window) {
    const phantom = (window as Window & { phantom?: { solana?: { isPhantom?: boolean; signAndSendTransaction?: (tx: Transaction) => Promise<{ signature: string }>; signTransaction?: (tx: Transaction) => Promise<Transaction> } } }).phantom;
    if (phantom?.solana?.isPhantom) return phantom.solana;
  }
  const w = window as Window & { solana?: { isPhantom?: boolean; signAndSendTransaction?: (tx: Transaction) => Promise<{ signature: string }>; signTransaction?: (tx: Transaction) => Promise<Transaction> } };
  if (w.solana?.isPhantom) return w.solana;
  return null;
}

function getSolflareProvider() {
  if (typeof window === "undefined") return null;
  const w = window as Window & { solflare?: { isSolflare?: boolean; signAndSendTransaction?: (tx: Transaction) => Promise<{ signature: string }>; signTransaction?: (tx: Transaction) => Promise<Transaction> } };
  if (w.solflare?.isSolflare) return w.solflare;
  return null;
}

export function useSolanaPayment(): UseSolanaPaymentReturn {
  const { address, walletName, connection } = useWallet();
  const [status, setStatus] = useState<PaymentStatus>("idle");
  const [error, setError] = useState<string | null>(null);

  const reset = useCallback(() => {
    setStatus("idle");
    setError(null);
  }, []);

  const sendSol = useCallback(
    async ({ recipient, amountSol }: { recipient: string; amountSol: number; memo?: string }): Promise<PaymentResult | null> => {
      if (!address) {
        setError("Wallet not connected");
        setStatus("error");
        return null;
      }

      try {
        setError(null);
        setStatus("building");

        const fromPubkey = new PublicKey(address);
        const toPubkey = new PublicKey(recipient);
        const lamports = Math.round(amountSol * LAMPORTS_PER_SOL);

        if (lamports <= 0) {
          throw new Error("Amount too small");
        }

        const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");

        const transaction = new Transaction({
          recentBlockhash: blockhash,
          feePayer: fromPubkey,
        }).add(
          SystemProgram.transfer({ fromPubkey, toPubkey, lamports })
        );

        setStatus("awaiting_approval");

        let signature: string;

        if (walletName === "Phantom") {
          const provider = getPhantomProvider();
          if (!provider) throw new Error("Phantom not found");

          if (provider.signAndSendTransaction) {
            const result = await provider.signAndSendTransaction(transaction);
            signature = result.signature;
          } else if (provider.signTransaction) {
            const signed = await provider.signTransaction(transaction);
            setStatus("sending");
            signature = await connection.sendRawTransaction(signed.serialize());
          } else {
            throw new Error("Phantom provider does not support signing");
          }
        } else if (walletName === "Solflare") {
          const provider = getSolflareProvider();
          if (!provider) throw new Error("Solflare not found");

          if (provider.signAndSendTransaction) {
            const result = await provider.signAndSendTransaction(transaction);
            signature = result.signature;
          } else if (provider.signTransaction) {
            const signed = await provider.signTransaction(transaction);
            setStatus("sending");
            signature = await connection.sendRawTransaction(signed.serialize());
          } else {
            throw new Error("Solflare provider does not support signing");
          }
        } else {
          throw new Error("No wallet connected");
        }

        setStatus("confirming");

        const result = await connection.confirmTransaction(
          { signature, blockhash, lastValidBlockHeight },
          "confirmed"
        );

        const confirmed = !result.value.err;
        setStatus("confirmed");

        return { txHash: signature, confirmed };
      } catch (err: unknown) {
        if (err && typeof err === "object" && "code" in err) {
          const code = (err as { code: number }).code;
          if (code === 4001) {
            setStatus("idle");
            return null;
          }
        }
        const message = err instanceof Error ? err.message : "Transaction failed";
        setError(message);
        setStatus("error");
        return null;
      }
    },
    [address, walletName, connection]
  );

  return { status, error, sendSol, reset };
}
